/*
 * ataquebehavior.cpp
 *
 *  Created on: 10 de dez de 2018
 *      Author: ERUS
 */

#include "ataquebehavior.h"

AtaqueBehavior::AtaqueBehavior() {}

AtaqueBehavior::~AtaqueBehavior() {}

Ponto AtaqueBehavior::movimenta(Ponto posicao, World* mundo){
return Ponto();
}

std::pair<int,int> AtaqueBehavior::controle(Ponto posicao, World* mundo){
return pair<int,int>();
}
