#ifndef CAMERA_H
#define CAMERA_H


class Camera
{
public:
    Camera();
};

#endif // CAMERA_H