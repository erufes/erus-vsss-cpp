#include "enemy.h"

Enemy::Enemy(int id,float theta) : Player(id, theta){

}

Enemy::~Enemy() {
	// TODO Auto-generated destructor stub
}

