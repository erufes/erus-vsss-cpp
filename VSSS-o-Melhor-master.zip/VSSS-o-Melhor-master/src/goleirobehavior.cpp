/*
 * goleirobehavior.cpp
 *
 *  Created on: 10 de dez de 2018
 *      Author: ERUS
 */

#include "goleirobehavior.h"

GoleiroBehavior::GoleiroBehavior() {}

GoleiroBehavior::~GoleiroBehavior() {}

Ponto GoleiroBehavior::movimenta(Ponto posicao, World* mundo){
	//todo: implementar GoleiroBehavior::movimenta
	return Ponto();
}

std::pair<int,int> GoleiroBehavior::controle(Ponto posicao, World* mundo){
	//todo: implementar GoleiroBehavior::controle
	return std::pair<int,int>();
}
