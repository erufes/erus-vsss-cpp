//
// Created by johnathan on 07/07/18.
//

#ifndef VSS_SIMULATOR_MATH_H
#define VSS_SIMULATOR_MATH_H

namespace Math {

    float radianToDegree(float radian);
    float degreeToRadian(float degree);

};

#endif //VSS_SIMULATOR_MATH_H
