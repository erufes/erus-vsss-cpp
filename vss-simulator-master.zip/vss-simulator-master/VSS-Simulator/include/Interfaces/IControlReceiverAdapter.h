//
// Created by johnathan on 07/07/18.
//

#ifndef VSS_SIMULATOR_ICONTROLRECEIVERADAPTER_H
#define VSS_SIMULATOR_ICONTROLRECEIVERADAPTER_H

class IControlReceiverAdapter {
public:
    virtual void loop() = 0;
};

#endif //VSS_SIMULATOR_ICONTROLRECEIVERADAPTER_H
