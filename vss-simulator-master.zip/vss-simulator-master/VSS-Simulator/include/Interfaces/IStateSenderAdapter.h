//
// Created by john on 01/09/18.
//

#ifndef VSS_SIMULATOR_ISTATESENDERADAPTER_H
#define VSS_SIMULATOR_ISTATESENDERADAPTER_H

class IStateSenderAdapter {
public:
    virtual void send() = 0;
};

#endif //VSS_SIMULATOR_ISTATESENDERADAPTER_H
